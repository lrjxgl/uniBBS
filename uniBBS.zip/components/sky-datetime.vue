<template>
	<view>
		<view class="flex">
			<picker mode="date" class="mgr-20">日期</picker>
			<picker mode="time">时间</picker>
		</view>
	</view>
</template>

<script>
	export default{
		
	}
</script>

<style>
</style>
