export default{
	noticeTimer:0
}