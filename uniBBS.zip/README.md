# uniBBS
# 安装说明
* http://uniapp.dcloud.io/ 
* 下载HBuilderX 
* 用HBuilderX打开目录或者直接从git新建项目 
# 其它说明
* ui采用dt-ui模板库  https://github.com/lrjxgl/dt-ui 
* 后台使用 deituiCMS+论坛插件  http://www.deituicms.com/ 
# 技术支持
* QQ：362606856 
* uniAPP实战群:277542543
* deituiCMS交流群：48353999 
